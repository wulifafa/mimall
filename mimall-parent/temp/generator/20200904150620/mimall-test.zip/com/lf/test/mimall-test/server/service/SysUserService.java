package com.lf.test.mimall-test.server.service;

import com.lf.test.mimall-test.client.model.entity.SysUser;
import com.jiuair.cloud.data.common.core.mybatis.base.service.IBaseService;

/**
 *  服务类
 *
 * @author lf
 * @date 2020-09-04
 */
public interface SysUserService extends IBaseService<SysUser> {

}
